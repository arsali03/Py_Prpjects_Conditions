print("___________Geometric figure area calculation_____________")

triangleOrGuadrilateral = input("Is the shape you want to calculate a triangle or a quadrilateral ? \n")

if(triangleOrGuadrilateral == "quadrilateral"):

    first_edge =  int(input("Please enter the length of the first edge: "))
    second_edge = int(input("Please enter the length of the second edge: "))
    third_edge = int(input("Please enter the length of the third edge: "))
    fourth_edge = int(input("Please enter the length of the fourth edge: "))


    if(first_edge == second_edge and third_edge == fourth_edge and third_edge == first_edge):

        print("This shape is square...")
    else:
        print("This shape is quadrilateral..")
elif (triangleOrGuadrilateral == "triangel"):
    first_edge1 = int(input("Please enter the length of the first edge: "))
    second_edge1 = int(input("Please enter the length of the second edge: "))
    third_edge1 = int(input("Please enter the length of the third edge: "))

    if(first_edge1 == second_edge1 and second_edge1 == third_edge1):
        print("This triangle is equilateral triangle..")
    elif(first_edge1 == second_edge1 or second_edge1 == third_edge1 or first_edge1 == third_edge1):
        print("This triangel is isosceles triangle..")
    else:
        print("This triangel is scalene triangle..")
else:
    print("This shape is not triangle or quadrilateral !!")






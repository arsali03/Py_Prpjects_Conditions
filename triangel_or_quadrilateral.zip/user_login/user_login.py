print("______________Welcome to login page_______________")

sys_username = "ali"
sys_password = 12345

username = input("username: ")
password = int(input("password: "))

if (sys_username == username and sys_password != password):
    print("password is wrong!!")
elif (sys_username != username and sys_password == password):
    print("username is wrong!!")
elif (sys_username != username and sys_password != password):
    print("username and password is wrong!!")
else:
    print("login is successful...")

print("_____Grade Calculation______")
q1 = int(input("Quiz 1: "))
q2 = int(input("Quiz 2: "))
final = int(input("Final: "))

total = final*4/10 + q1*3/10 + q2*3/10

if (total >= 90):
    print("Your passing grade: AA")
elif (total >= 85):
    print("Your passing grade: BA")
elif (total >= 80):
    print("Your passing grade: BB")
elif (total >= 75):
    print("Your passing grade: CB")
elif (total >= 70):
    print("Your passing grade: CC")
elif (total >= 65):
    print("Your passing grade: DC")
elif (total >= 60):
    print("Your passing grade: DD")
elif (total >= 55):
    print("Your passing grade: FD")
else:
    print("Your passing grade: FF")